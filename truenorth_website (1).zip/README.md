# TrueNorth Logistics Services Website

## Overview
TrueNorth Logistics Services is a U.S.-based transportation dispatch company providing fast, reliable, and affordable dispatch solutions for owner-operators and small fleets.

## Deployment (GitHub Pages)
1. Commit and push all files to your main branch on GitHub.
2. Go to **Settings → Pages** in your repo.
3. Under **Source**, select `main` branch and `/root`.
4. Save — your site will be live at:
   https://yourusername.github.io/truenorth-logistics/
